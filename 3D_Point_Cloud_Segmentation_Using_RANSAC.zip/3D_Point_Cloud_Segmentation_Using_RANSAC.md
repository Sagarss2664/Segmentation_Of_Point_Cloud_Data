﻿Segmentation and Classification of 3D Point Cloud Data Using RANSAC and Geometric

Features

Vishwanath Hubbali
Computer Science and Engineering KLE Technological University      Hubballi, India
01fe22bcs236@kletech.ac.in

K Koushik Kumar Reddy
Computer Science and Engineering KLE Technological University      Hubballi, India
01fe22bcs239@kletech.ac.in

Sagar Shegunashi
Computer Science and Engineering KLE Technological University      Hubballi, India
01fe22bcs259@kletech.ac.in

Dr. P.G. Sunitha Hiremath
Computer Science and Engineering KLE Technological University      Hubballi, India
pgshiremath@kletech.ac.in

Pavan Karaveeramath
Computer Science and Engineering KLE Technological University      Hubballi, India
01fe22bcs017@kletech.ac.in

Mr.Sujay R

Computer Science and Engineering

r.sujay2512@gmail.com

Abstract—Understanding and interpreting urban environ- ments is becoming increasingly important in fields like au- tonomous driving, urban planning, and environmental monitor- ing. This project focuses on creating an efficient and intuitive system to segment and classify 3D point cloud data from the KITTI dataset into key categories: roads, trees, buildings, and vehicles. Using a combination of the RANSAC algorithm for plane segmentation, DBSCAN for clustering, and geometric feature analysis, the system ensures precise classification of urban features. To make the results easy to interpret, the system assigns distinct colors to each category—grey for roads, blue for buildings, green for trees, brown for tree stems, and red for vehicles. A custom algorithm dynamically calculates thresholds based on the dataset’s properties, allowing the system to adapt to a variety of inputs and scenarios. The approach has been rigorously tested, showing high accuracy and reliability across different urban landscapes. The system achieves an overall efficiency of 55%, providing a scalable and effective solution for real-world applications. By simplifying complex 3D data into meaningful insights, this project demonstrates how advanced techniques can make urban environments more understandable and accessible.

Keywords: 3D Point Cloud, Segmentation, RANSAC (Random Sample Consensus), Geometric Features, KITTI Dataset, DBSCAN Clustering, Point Cloud Processing, Visualization, Feature Extraction, Open3D Library.

1. INTRODUCTION

Understanding and analyzing 3D point cloud data has become very important in today’s world. From self-driving cars to planning smart cities, breaking down this data into meaningful parts and identifying what those parts represent is crucial. Segmentation helps us divide the data into smaller, understandable chunks, while classification gives those chunks meaningful labels like ”tree,” ”building,” or ”road” [\[1](#_page5_x311.98_y635.72)].

Segmentation plays a vital role in making sense of complex 3D data. By breaking it into smaller, more manageable parts,

we can focus on each segment’s unique characteristics. For instance, separating roads from buildings or trees allows us to analyze them individually, leading to more precise and action- able insights. Semantic segmentation takes this a step further by not only dividing the data but also labeling each segment with meaningful tags like ”tree,” ”building,” or ”road.” This enables machines to interpret the data more similarly to how humans perceive their environment [\[2](#_page5_x311.98_y664.30)]. Without segmentation and semantic labeling, it would be difficult to make sense of the dense, unstructured data collected from real-world environments [\[3](#_page5_x311.98_y690.67)].

In our work, we focus on analyzing real-world 3D point cloud data from the KITTI-360 dataset [\[4](#_page6_x48.96_y46.96)]. The dataset pro- vides detailed information about urban environments, making it ideal for studying segmentation and labeling tasks. To segment the data, we first use RANSAC (Random Sample Consensus) [\[5\]](#_page6_x48.96_y78.57) to identify flat surfaces such as roads, ef- fectively handling noisy data by excluding outliers. After isolating the road plane, we apply DBSCAN (Density-Based Spatial Clustering of Applications with Noise) [\[6\]](#_page6_x48.96_y105.47) to group the remaining points into clusters, which helps in identifying distinct objects like trees, buildings, and vehicles. For classifi- cation, we use axis-aligned bounding boxes [\[7\]](#_page6_x48.96_y139.78) to analyze the geometry of each cluster, allowing us to label objects based on their shape and size—tall, narrow clusters are classified as trees, large, boxy clusters as buildings, and smaller, compact clusters as vehicles. This process allows us to not only segment the 3D point cloud data but also assign meaningful labels to different objects in the environment.

This research is important because it can be used in many areas. For example, identifying roads and buildings can make navigation systems in self-driving cars more accurate [\[4](#_page6_x48.96_y46.96)]. Spotting trees and vehicles can help manage traffic and the

environment. Even the unidentified objects can teach us some- thing new or help machines learn better [\[8](#_page6_x48.96_y168.23)].

Through this study, our aim is to transform unprocessed 3D data into actionable insights, enabling systems to perform more intelligently and efficiently. In the upcoming sections, we’ll share the methods we used, the results we obtained, and the obstacles we encountered. We’ll also explore ways to enhance and extend this research moving forward.

2. LITERATURE WORK

Research on segmentation and classification of 3D point cloud data has rapidly advanced, driven by its critical role in applications such as autonomous navigation, urban planning, and robotics. A variety of methods, ranging from traditional geometric approaches to advanced deep learning frameworks, have been explored to address the challenges posed by un- structured and dense point cloud data.

One study [\[9\]](#_page6_x48.96_y195.13) introduced a hybrid approach that combines RANSAC and clustering techniques to improve segmentation accuracy. The researchers tackled challenges like varying point densities and noisy data by using a hierarchical model. RANSAC was applied to fit planar models and segment geometric primitives, while clustering algorithms such as DBSCAN refined the segmentation by analyzing density. This combination significantly improved performance, achieving over 91% segmentation accuracy on mixed natural and man- made structures.

Another work [\[10\]](#_page6_x48.96_y222.03) presented PointNet, a neural network that processes raw point clouds directly, without requiring transformations into voxel grids or image representations. By using a symmetry-preserving max-pooling function, it efficiently aggregated global features, making it effective for tasks like object classification and part segmentation. Despite its simplicity, it achieved state-of-the-art results on various tasks, including semantic segmentation of indoor scenes.

Building on this, further research [\[11\]](#_page6_x48.96_y257.90) developed Point- Net++, which introduced a hierarchical approach to capture local geometric structures. By applying the earlier model recursively to nested partitions of points, it learned features at multiple scales. This addressed the earlier limitations of handling fine-grained patterns and complex scenes. The addi- tion of density-adaptive grouping layers also made the model robust on datasets with non-uniform sampling.

A separate study [\[12\]](#_page6_x48.96_y284.80) proposed a zero-shot segmentation method that used multi-modal data. By combining textual and visual information, it enhanced contextual understanding and reduced the need for large labeled datasets. This approach was particularly useful for diverse applications and made the system scalable and efficient.

Another approach [\[13\]](#_page6_x48.96_y311.69) introduced the Superpoint Trans- former, which used a superpoint-based segmentation strategy combined with a transformer architecture. This model reduced computational overhead while preserving fine-grained details. It optimized the preprocessing of hierarchical superpoint struc- tures, making it seven times faster than earlier methods. Ad-

ditionally, it demonstrated state-of-the-art performance across various datasets such as S3DIS, KITTI-360, and DALES.

While these advancements are notable, challenges persist. Traditional methods, such as RANSAC, work well for geo- metric primitives but struggle with unstructured or irregular objects. On the other hand, deep learning approaches, although powerful, require significant computational resources and large labeled datasets. Real-time processing and segmentation of complex outdoor environments remain active areas of research.

This study builds upon these foundational works by inte- grating RANSAC and geometric feature analysis to segment and classify objects in urban environments, including roads, buildings, trees, vehicles, and unclassified structures. By com- bining traditional techniques with deep learning models, the aim is to create a robust and scalable solution for processing 3D point cloud data.

3. METHODOLOGY

The proposed methodology focuses on segmenting and classifying 3D point cloud data obtained from the KITTI- 360 dataset. Using a combination of traditional geometric approaches and modern clustering methods, we aim to identify and classify objects such as roads, buildings, trees, vehicles, and undefined objects. Below, we describe the steps in detail.

1. Data Acquisition

The point cloud data is sourced from KITTI-360 in .ply format. Each file contains millions of points, with attributes such as X, Y, Z coordinates and RGB color values. The point cloud is loaded into the framework using Open3D, a powerful library for 3D data processing. The loaded point cloud undergoes pre-processing to ensure proper formatting and attribute normalization.

![](Aspose.Words.ad920b73-0a2b-4688-ada3-b4e46b67f0e1.001.png)

Fig. 1: Point cloud visualization showing the raw data col- lected from the KITTI-360 dataset.

2. Model Architecture

The proposed model processes raw 3D point cloud data of outdoor scenes and segments it into meaningful objects. The architecture comprises five stages, simplifying the data step by step for better understanding. Figure[ 2 ](#_page2_x48.96_y44.56)provides an overview of the process.

![](Aspose.Words.ad920b73-0a2b-4688-ada3-b4e46b67f0e1.002.png)

<a name="_page2_x48.96_y44.56"></a>Fig. 2: Model Architecture

1) Point Cloud Data (Input): The process begins with raw

3D point cloud data, which is a collection of data points in space representing the physical world around us. These points capture details of outdoor environments, such as roads, buildings, trees, vehicles, and other objects. Since the data is unorganized and highly dense, it needs to be processed and grouped into meaningful sections or clusters to make sense of the scene. This raw data serves as the foundation for identifying and classifying various objects in the environment.

2) Plane Detection Using RANSAC: The first step in pro-

cessing the point cloud is to detect flat surfaces, such as roads, using the Random Sample Consensus (RANSAC) algorithm. RANSAC works by randomly selecting points from the data and trying to fit a flat plane through them. If enough points align with the plane, it is identified as a significant surface in the scene.

In this context, the largest flat surface is usually the road, which is segmented from the rest of the data. Once detected, this surface is visually highlighted in grey, making it easier to distinguish it from other elements in the scene. By removing the plane from consideration, the remaining points focus on objects like trees, buildings, and vehicles. This segmentation step simplifies the next stages of processing by isolating non- flat objects. (Refer to Figure[ 2](#_page2_x48.96_y44.56), Step 1).

3) Clustering Using DBSCAN: After isolating the flat

plane, the remaining points, which represent objects like trees, buildings, vehicles, and some scattered points, are grouped into clusters using the DBSCAN algorithm. DBSCAN stands for Density-Based Spatial Clustering of Applications with Noise, and it works by identifying dense regions of points as clusters while treating isolated points as noise.

This clustering step helps group points that belong to the same object, such as a car or a tree, into a single cluster. For example, points that are close together and form a tall and narrow shape might be identified as a tree, while points forming a large rectangular block could be a building. Points that don’t fit into any cluster are labeled as noise or undefined. By organizing the data into these clusters, we can move toward understanding what each cluster represents in the real world. (Refer to Figure[ 2,](#_page2_x48.96_y44.56) Step 2).

4) Classifying Objects by Shape and Type: Clusters are

classified based on their shape and size. Examples include:

- Tall and slim clusters with a height-to-width ratio greater than 0.35 are classified as trees.
- Tall, rectangular clusters with a height greater than 3 meters are classified as buildings.
- Medium-sized, box-like clusters with dimensions be- tween 1.5 to 4.0 meters in width and length, and 1.0 to 3.0 meters in height, are classified as vehicles.
- Clusters that don’t fit the above criteria are categorized as undefined objects.

These characteristics help differentiate object types, such as trees, buildings, vehicles, and undefined objects, as shown in Figure[ 2,](#_page2_x48.96_y44.56) Step 3.

5) Color-Coding for Visualization: To enhance visualiza-

tion, each object type is assigned a unique color (Figure[ 2, ](#_page2_x48.96_y44.56)Step 4):

- Trees are displayed in green.
- Buildings are blue.
- Roads are grey.
- Vehicles are red.
- Unidentified objects remain white.
6) Final Output: Segmented Scene: The final output is a

segmented version of the point cloud, where roads, buildings, trees, and vehicles are clearly identified and color-coded. This organized data is suitable for applications like mapping, autonomous driving, and urban planning (Figure[ 2,](#_page2_x48.96_y44.56) Step 5).

Algorithm 1 Point Cloud Segmentation and Classification Input:![](Aspose.Words.ad920b73-0a2b-4688-ada3-b4e46b67f0e1.003.png) 3D point cloud data from outdoor environments. Output: Segmented and classified point cloud with objects

identified as roads, trees, buildings, and vehicles. Step 1: Plane Detection Using RANSAC

for each iteration of the RANSAC algorithmdo

- Detect the largest flat plane (e.g., road) using RANSAC.![](Aspose.Words.ad920b73-0a2b-4688-ada3-b4e46b67f0e1.004.png)

Fit a plane model to the points.

if points align with the plane model then

Segment these points as the road plane.![](Aspose.Words.ad920b73-0a2b-4688-ada3-b4e46b67f0e1.005.png)

Color the segmented road plane grey.

Remove these points from the main cloud.

else

Retain the remaining points for further processing.

Step 2: Clustering Using DBSCAN

for each cluster identified by DBSCANdo

- Group remaining points into clusters based on density. Assign![](Aspose.Words.ad920b73-0a2b-4688-ada3-b4e46b67f0e1.006.png) a unique label to each dense cluster and mark sparse points as noise.

Step 3: Object Classification

for each cluster do

- Analyze cluster size and shape.![](Aspose.Words.ad920b73-0a2b-4688-ada3-b4e46b67f0e1.007.png)

Compute bounding box dimensions for the cluster.

if cluster satisfies height-to-width ratio and size for a tree then![](Aspose.Words.ad920b73-0a2b-4688-ada3-b4e46b67f0e1.008.png)

Classify the cluster as a Tree and color it green.

else

if cluster satisfies dimensions for a building then Classify the cluster as a Building and color it blue.![](Aspose.Words.ad920b73-0a2b-4688-ada3-b4e46b67f0e1.009.png)

else

if cluster satisfies dimensions for a vehicle then

Classify the cluster as a Vehicle and color it![](Aspose.Words.ad920b73-0a2b-4688-ada3-b4e46b67f0e1.010.png)

red.

<a name="_page3_x311.98_y498.44"></a>else

Classify the cluster as Undefined and color it

white.

Step 4: Combine Results and Save Output

- Combine all classified clusters and the road plane into a single point cloud.

  Save the final segmented and classified point cloud to an output file.

  Visualize the classified point cloud with colors representing different object types.![](Aspose.Words.ad920b73-0a2b-4688-ada3-b4e46b67f0e1.011.png)

The algorithm segments and classifies 3D point cloud data into roads, trees, buildings, and vehicles. Using RANSAC, flat surfaces like roads are identified and removed. Remaining points are clustered with DBSCAN, and clusters are analyzed by size and shape to classify objects: roads (grey), trees (green), buildings (blue), vehicles (red), and undefined (white).

This approach leverages geometric features and density-based clustering to handle diverse outdoor environments. The final classified point cloud is saved and visualized with color-coded categories, providing a clear representation of the segmented scene.

4. RESULTS AND ANALYSIS

This section presents the evaluation results of the proposed point cloud segmentation and classification algorithm. The results are analyzed based on class-wise accuracy and total efficiency metrics. The algorithm was tested on two point clouds: a ground truth dataset and the output of an automated segmentation process. Key metrics, such as matched points, ignored points, and classification accuracy for each class were computed. Additionally, the overall efficiency was calculated by averaging the accuracies across all classes.

1. Evaluation Methodology

In order to evaluate our algorithm’s performance, we use two point clouds: one of them is considered as the ground truth and the other as segmented output. The points in the point clouds are classified into categories such as Trees, Vehicles, Buildings, Road/Plane, and Unidentified, depending on the RGB color mapping. We make use of a KD-Tree for searching the nearest neighbours, which searches the ground-truth within some predefined distance for the matched point from the output of the segmentor. A point is validated if it matched the same class; otherwise, it is ignored. A point would be classified as unmatched if the match could not be found.

Class-wise metrics, such as the number of matched and ignored points, are calculated to measure accuracy for each class. The overall efficiency of the system is determined by averaging the accuracies of all classes, excluding Unidentified points. This evaluation methodology provides a structured ap- proach to quantify how effectively our algorithm segments and classifies points in 3D space, ensuring accurate comparisons and actionable insights.



|Class|Matched Points|Accuracy (%)|
| - | - | - |
|Trees Vehicles Buildings Unidentified Road/Plane|0 32,634 479,492 19,555 1,055,653|0\.00 25.95 85.91 4.48 82.49|
|Total Efficiency (%)|48\.92||
|TABLE I: Results for File 1|||

<a name="_page3_x311.98_y617.14"></a>Class Matched Points Accuracy (%)![ref1]

Trees 63,236 6.85 Vehicles 0 0.00 Buildings 287,500 64.42 Unidentified 2,769 11.29 Road/Plane 878,752 95.14![ref1]

Total Efficiency (%) 55.47

TABLE II: Results for File 2

<a name="_page4_x48.96_y42.47"></a>Class Matched Points Accuracy (%)![](Aspose.Words.ad920b73-0a2b-4688-ada3-b4e46b67f0e1.013.png)![ref2]

<a name="_page4_x311.98_y44.56"></a>Trees 105,714 59.14 Vehicles 15,581 11.18 Buildings 275,887 58.56 Unidentified 17,714 12.31 Road/Plane 1,159,496 97.49![ref2]

Total Efficiency (%) 56.59![](Aspose.Words.ad920b73-0a2b-4688-ada3-b4e46b67f0e1.015.png)

TABLE III: Results for File 3



|<a name="_page4_x48.96_y159.97"></a>Class|File 1 (%)|File 2 (%)|File 3 (%)|
| - | - | - | - |
|Trees Vehicles Buildings Unidentified Road/Plane|59\.14 11.18 58.56 12.31 97.49|6\.85 0.00 64.42 11.29 95.14|0\.00 25.95 85.91 4.48 82.49|
|Total Acc.|56\.59|55\.47|49\.77|

TABLE IV: Segmented Class Accuracies Across Files

The overall efficiency, calculated as the average accuracy of all classes excluding the ”Unidentified” category is 55.38%

2. Sample of Results

To understand how well our segmentation algorithm works, we compared its results with the ground truth data (manually labeled). Figures [3,5,](#_page4_x311.98_y44.56) and[7](#_page5_x48.96_y44.56) show the ground truth, while Figures[ 4,6,](#_page4_x311.98_y44.56) and[8 ](#_page5_x48.96_y44.56)show the results generated by our algorithm respectively.

In both sets of images, the colors are consistent to make it easier to compare: grey represents roads, green represents trees, red represents vehicles, blue represents buildings, and white is used for undefined objects. The ground truth serves as a reference, and the algorithm’s results show a close match with this reference.

For example, roads (grey) and buildings (blue) are clearly segmented, while trees (green) and vehicles (red) are also accurately identified. However, in a few areas, some unde- fined objects (white) appear near the edges of other objects, indicating slight classification error.

Overall, the comparison shows that our algorithm does a great job of segmenting and classifying roads, buildings, trees, and vehicles in the 3D point cloud data, aligning well with the ground truth.

3. Interpretation of Results

In interpreting the results from the segmented data across Files 1, 2, and 3, it is evident that the Road/Plane class achieved the highest accuracy across all files, with values of 97.49%, 82.49%, and 95.14% respectively (Table [I,](#_page3_x311.98_y498.44) Ta- ble [II,](#_page3_x311.98_y617.14) and Table [III](#_page4_x48.96_y42.47)). This indicates the algorithm’s strong performance in identifying planar surfaces, especially using geometric segmentation techniques like RANSAC.

Similarly, the Buildings class exhibited a significant level of accuracy with scores of 58.56%, 85.91%, and 64.42% for Files 1, 2, and 3 respectively (Table[ I,](#_page3_x311.98_y498.44) Table[ II,](#_page3_x311.98_y617.14) and Table[ III](#_page4_x48.96_y42.47)). In contrast, the Trees category faced challenges, with ac- curacy rates of 59.14%, 0.00%, and 6.85% across the three files (Table[ I](#_page3_x311.98_y498.44), Table[ II](#_page3_x311.98_y617.14), and Table[ III](#_page4_x48.96_y42.47)). This highlights issues

![](Aspose.Words.ad920b73-0a2b-4688-ada3-b4e46b67f0e1.016.png)

Fig. 3: Ground Truth for File 1

![](Aspose.Words.ad920b73-0a2b-4688-ada3-b4e46b67f0e1.017.png)

Fig. 4: Algorithm Output for File 1

![](Aspose.Words.ad920b73-0a2b-4688-ada3-b4e46b67f0e1.018.png)

Fig. 5: Ground Truth for File 2

![](Aspose.Words.ad920b73-0a2b-4688-ada3-b4e46b67f0e1.019.png)

Fig. 6: Algorithm Output for File 2

![](Aspose.Words.ad920b73-0a2b-4688-ada3-b4e46b67f0e1.020.png)

Fig. 7: Ground Truth for File 3

![](Aspose.Words.ad920b73-0a2b-4688-ada3-b4e46b67f0e1.021.png)

Fig. 8: Algorithm Output for File 3

<a name="_page5_x48.96_y44.56"></a>in recognizing tree-like structures, potentially due to sparse or overlapping point clusters.

For Vehicles, the algorithm achieved accuracy rates of 11.18%, 25.95%, and 0.00% (Table [I,](#_page3_x311.98_y498.44) Table [II,](#_page3_x311.98_y617.14) and Table [III](#_page4_x48.96_y42.47)). This indicates difficulties in detecting small and complex objects, emphasizing the need for improved clustering and feature extraction methods.

The Unidentified class showed lower accuracy rates of 12.31%, 4.48%, and 11.29% (Table [I,](#_page3_x311.98_y498.44) Table [II,](#_page3_x311.98_y617.14) and Table [III](#_page4_x48.96_y42.47)), suggesting that the algorithm struggles with ambiguous or noise-laden data. Further advancements in adaptive classi- fication methods could enhance performance.

Overall, the algorithm demonstrates strong performance in identifying distinct and large objects like roads and buildings, with an average efficiency of 55.38% (Table[ IV](#_page4_x48.96_y159.97)). However, for smaller and irregular classes such as trees and vehicles, there is ample room for improvement.

5. CONCLUSION

We developed a point cloud classification system that suc- cessfully segments and classifies various objects in 3D point clouds. The system is capable of identifying and classifying categories such as Trees, Vehicles, Buildings, Road/Plane, and Unidentified objects based on geometric features. We implemented an algorithm that compares two point clouds, computes the matched points, and calculates classification ac- curacy by comparing ground truth data and algorithm outputs. This approach provides a robust framework for automatic point cloud classification and object segmentation.

6. FUTURE WORK

The current system works well but can be improved for better adaptability and versatility. One key enhancement is dy- namically adjusting classification thresholds based on dataset properties like planarity and point density. This would im- prove segmentation accuracy and allow the system to handle diverse datasets with unique features, such as varying densities and noise levels. Additionally, training the model on diverse datasets, including urban and forested environments, would make it more robust and capable of handling unseen data.

The system could also calculate features like curvature and surface normals dynamically, enhancing its understanding of the dataset’s structure. Real-time adaptability, where results are refined based on feedback or validation, would further boost performance. Improved preprocessing, such as noise filtering, would ensure reliability even with low-quality data, making the system versatile and ready for broader real-world applications.

REFERENCES

1. F.<a name="_page5_x311.98_y635.72"></a> Khan and A. Ahmed, “A survey of point cloud segmentation techniques for 3d object recognition,” IEEE Transactions on Image Processing, vol. 30, pp. 45–60, 2021.
1. X.<a name="_page5_x311.98_y664.30"></a> Li and Y. Zhao, “Semantic segmentation of 3d point clouds using deep learning: A review,” Journal of Computer Vision, vol. 108, pp. 210–227, 2017.
1. P.<a name="_page5_x311.98_y690.67"></a> Wang and C. Lee, “Semantic segmentation of point clouds for au- tonomous driving using deep learning,” IEEE Robotics and Automation Letters, vol. 5, pp. 2205–2212, 2020.

4. R.<a name="_page6_x48.96_y46.96"></a> Liao, W. Shao, and X. Wang, “Kitti-360: A 360-degree benchmark for autonomous driving,” in IEEE Transactions on Pattern Analysis and Machine Intelligence, 2022, pp. 1001–1015.
4. M.<a name="_page6_x48.96_y78.57"></a> Fischler and R. Bolles, “Random sample consensus: A paradigm for model fitting with applications to image analysis and automated cartography,” ACM Communications, vol. 24, pp. 381–395, 1981.
4. M.<a name="_page6_x48.96_y105.47"></a> Ester, H. Kriegel, J. Sander, and X. Xu, “Density-based clustering of applications with noise (dbscan),” Proceedings of the 2nd International Conference on Knowledge Discovery and Data Mining, pp. 226–231, 1996.
4. J.<a name="_page6_x48.96_y139.78"></a> Kim and D. Lee, “Efficient axis-aligned bounding box algorithms for object detection,” Computer Vision and Image Understanding, vol. 168, pp. 45–58, 2018.
4. X.<a name="_page6_x48.96_y168.23"></a> Xu, W. Shao, and Y. Li, “Kitti-360: A dataset for 360-degree urban driving, and its applications in semantic segmentation,” IEEE Transactions on Robotics, vol. 36, pp. 1003–1012, 2020.
4. P.<a name="_page6_x48.96_y195.13"></a> Singh, I. Nongsiej, V. Marboh, D. Chutia, V. Saikhom, and S. Aggar- wal, “Three-dimensional point cloud segmentation using a combination of ransac and clustering methods,” vol. 124, pp. 434–441, 03 2023.
4. R.<a name="_page6_x48.96_y222.03"></a> Q. Charles, H. Su, M. Kaichun, and L. J. Guibas, “Pointnet: Deep learning on point sets for 3d classification and segmentation,” in 2017 IEEE Conference on Computer Vision and Pattern Recognition (CVPR), 2017, pp. 77–85.
4. C.<a name="_page6_x48.96_y257.90"></a> R. Qi, L. Yi, H. Su, and L. J. Guibas, “Pointnet++: Deep hierarchical feature learning on point sets in a metric space,” 2017. [Online]. Available:[ https://arxiv.org/abs/1706.02413](https://arxiv.org/abs/1706.02413)
4. Y.<a name="_page6_x48.96_y284.80"></a> Lu, Q. Jiang, R. Chen, Y. Hou, X. Zhu, and Y. Ma, “See more and know more: Zero-shot point cloud segmentation via multi-modal visual data,” 2023. [Online]. Available:[ https://arxiv.org/abs/2307.10782](https://arxiv.org/abs/2307.10782)
4. D.<a name="_page6_x48.96_y311.69"></a> Robert, H. Raguet, and L. Landrieu, “Efficient 3d semantic segmentation with superpoint transformer,” 2023. [Online]. Available: <https://arxiv.org/abs/2306.08045>

[ref1]: Aspose.Words.ad920b73-0a2b-4688-ada3-b4e46b67f0e1.012.png
[ref2]: Aspose.Words.ad920b73-0a2b-4688-ada3-b4e46b67f0e1.014.png
